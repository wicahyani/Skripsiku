<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RincianPinjaman extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::create('rincian_pinjaman', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->integer('id_peminjaman')->unsigned();
             $table->integer('id_gaji')->unsigned();
            $table->integer('urutan_cicilan');
            $table->integer('sisa_cicilan');
            $table->integer('pembayaran');
             $table->date('tgl_ACC');
            $table->date('tgl_permohonan_nominal_pembayaran');
            $table->rememberToken();
            $table->timestamps();
        });

         Schema::table('rincian_pinjaman', function($table) {
            $table->foreign('id_peminjaman')->references('id_peminjaman')->on('peminjaman');
            $table->foreign('id_gaji')->references('id_gaji')->on('gaji');
    });
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('rincian_pinjaman');
    }
}

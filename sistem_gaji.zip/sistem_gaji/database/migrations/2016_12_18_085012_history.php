<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class History extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('history', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->integer('id_gaji')->unsigned();
            $table->date('tgl_berlaku');
            $table->date('tgl_berakhir');
            $table->integer('honor_harian'); 
            $table->rememberToken();
            $table->timestamps();
        });

         Schema::table('history', function($table) {
            $table->foreign('id_gaji')->references('id_gaji')->on('gaji');
    });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('history');
    }
}

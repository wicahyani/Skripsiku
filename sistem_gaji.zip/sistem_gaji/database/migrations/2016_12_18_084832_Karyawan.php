<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Karyawan extends Migration
{

    public function up()
    {
       Schema::create('Karyawan', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id_Karyawan');
            $table->integer('id')->unsigned();
            $table->date('tgl_masuk');
            $table->date('tgl_berhenti')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
        Schema::table('Karyawan', function($table) {
            $table->foreign('id')->references('id')->on('users');
        });
    }

    public function down()
    {
      Schema::drop('Karyawan');
    }
}

<?php

use Illuminate\Database\Seeder;
use App\ biodataModel as biodata;
class biodataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $databiodata = array([
        	['alamat'=>"jakarta Barat",'tanggal_lahir'=>date("Y-m-d"),'jenis_kelamin'=>"perempuan",'no_Hp'=>123],
			['alamat'=>"Tangerang",'tanggal_lahir'=>date("Y-m-d"),'jenis_kelamin'=>"perempuan",'no_Hp'=>1234],
			['alamat'=>"jakarta Timur",'tanggal_lahir'=>date("Y-m-d"),'jenis_kelamin'=>"laki - laki",'no_Hp'=>1235],
			['alamat'=>"jakarta Selatan",'tanggal_lahir'=>date("Y-m-d"),'jenis_kelamin'=>"perempuan",'no_Hp'=>1238]
        	]);
        foreach ($databiodata as $data){
     biodata::insert($data);
    }
}
}
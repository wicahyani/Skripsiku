<?php

use Illuminate\Database\Seeder;
use App\ absensiModel as absensi;
class absensiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $dataabsensi = array([
        	['id_absensi'=>"1",'id_Karyawan'=>"1",'tgl'=>date("Y-m-d"),'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00",'keterangan'=>"hadir"],
			['id_absensi'=>"2",'id_Karyawan'=>"2",'tgl'=>date("Y-m-d"),'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00",'keterangan'=>"hadir"],
            ['id_absensi'=>"3",'id_Karyawan'=>"3",'tgl'=>date("Y-m-d"),'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00",'keterangan'=>"hadir"],
            ['id_absensi'=>"4",'id_Karyawan'=>"4",'tgl'=>date("Y-m-d"),'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00",'keterangan'=>"hadir"],
            
			
        	]);
        foreach ($dataabsensi as $data){
     absensi::insert($data);
    }
}
}
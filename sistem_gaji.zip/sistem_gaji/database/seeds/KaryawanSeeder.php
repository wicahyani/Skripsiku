<?php
use Illuminate\Database\Seeder;
use App\KaryawanModel as Karyawan;

class KaryawanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         $dataKaryawan = array([
        	['id_Karyawan'=>1,'id'=>1,'tgl_masuk'=>date("Y-m-d"),'tgl_berhenti'=>date("Y-m-d")],
        	['id_Karyawan'=>2,'id'=>2,'tgl_masuk'=>date("Y-m-d"),'tgl_berhenti'=>date("Y-m-d")],
        	['id_Karyawan'=>3,'id'=>3,'tgl_masuk'=>date("Y-m-d"),'tgl_berhenti'=>date("Y-m-d")],
        	['id_Karyawan'=>4,'id'=>4,'tgl_masuk'=>date("Y-m-d"),'tgl_berhenti'=>date("Y-m-d")]
        	]);
        foreach ($dataKaryawan as $data){
        	Karyawan::insert($data);}
                                     
    }
}
?>
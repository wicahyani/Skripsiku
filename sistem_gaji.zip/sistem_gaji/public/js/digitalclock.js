function clock() {// We create a new Date object and assign it to a variable called "time".
var time = new Date(),
    
    // Access the "getHours" method on the Date object with the dot accessor.
    hours = time.getHours(),
    
    // Access the "getMinutes" method with the dot accessor.
    minutes = time.getMinutes(),
    
    
    seconds = time.getSeconds();

document.querySelectorAll('.clock')[0].innerHTML = harold(hours) + ":" + harold(minutes) + ":" + harold(seconds);
if(hours>=7&&hours<=8)
$("#absen_masuk").show();
else $("#absen_masuk").hide();
if((hours==16&&minutes>=45)||(hours<=20&&hours>16))
  $("#absen_pulang").show();
else $("#absen_pulang").hide();
if(hours>=12&&hours==13)
$("#absen_istirahat1_keluar").show();
else $("#absen_istirahat1_keluar").hide();
if(hours==13)
$("#absen_istirahat1_masuk").show();
else $("#absen_istirahat1_masuk").hide();
if(hours==18&&minutes==0&&minutes<=15)
$("#absen_istirahat2_keluar").show();
else $("#absen_istirahat2_keluar").hide();
if(hours==18&&minutes==15&&minutes>=17)
$("#absen_istirahat2_masuk").show();
else $("#absen_istirahat2_masuk").hide();


  
  function harold(standIn) {
    if (standIn < 10) {
      standIn = '0' + standIn
    }
    return standIn;
  }
}
setInterval(clock, 1000);
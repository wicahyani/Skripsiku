<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lemburModel extends Model
{
    protected $table = "lembur";
    protected $fillable = array("id_lembur","id_Karyawan","tanggal","keterangan", "create_at", "update_at");
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gajiModel extends Model
{
   protected $table = "gaji";
    protected $fillable = array("id_Karyawan","honor_harian","create_at", "update_at"); 
}

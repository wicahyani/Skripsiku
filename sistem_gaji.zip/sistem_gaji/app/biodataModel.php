<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class biodataModel extends Model
{
    protected $table = "biodata";
    protected $fillable = array("nama_lengkap",
    	"alamat","tanggal_lahir","jenis_kelamin","no_Hp","create_at", "update_at");
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class absensiModel extends Model
{
    protected $table = "absensi";
    protected $fillable = array("id_Karyawan","tgl","jam_masuk","jam_keluar","jam_istirahat1_keluar","jam_istirahat1_masuk","jam_istirahat2_keluar","jam_istirahat2_masuk","keterangan","create_at", "update_at");

}

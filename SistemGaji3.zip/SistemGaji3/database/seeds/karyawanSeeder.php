<?php

use Illuminate\Database\Seeder;
use App\karyawanModel as karyawan;

class karyawanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $dataKaryawan = array([
        	['id'=>1,'tgl_masuk'=>date("Y-m-d"),'tgl_berhenti'=>date("Y-m-d")],
        	['id'=>2,'tgl_masuk'=>date("Y-m-d"),'tgl_berhenti'=>date("Y-m-d")],
        	['id'=>3,'tgl_masuk'=>date("Y-m-d"),'tgl_berhenti'=>date("Y-m-d")],
        	['id'=>4,'tgl_masuk'=>date("Y-m-d"),'tgl_berhenti'=>date("Y-m-d")]
        ]);
        foreach ($dataKaryawan as $data){
        	karyawan::insert($data);
        }
    }
}

<?php

use Illuminate\Database\Seeder;
use App\gajiModel as gaji;

class gajiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $datagaji = array([
        	['id_karyawan'=>1,'honor_harian'=>100000],
        	['id_karyawan'=>2,'honor_harian'=>200000],
        	['id_karyawan'=>3,'honor_harian'=>300000],
        	['id_karyawan'=>4,'honor_harian'=>400000]
        ]);
        foreach ($datagaji as $data){
         gaji::insert($data);
        }
    }
}

<?php

use Illuminate\Database\Seeder;
use App\ absensiModel as absensi;

class absensiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $dataabsensi = array([
        	['id_absensi'=>"1",'id_karyawan'=>"1",'tgl'=>date("Y-m-d"),'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
			['id_absensi'=>"2",'id_karyawan'=>"2",'tgl'=>date("Y-m-d"),'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"3",'id_karyawan'=>"3",'tgl'=>date("Y-m-d"),'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"4",'id_karyawan'=>"4",'tgl'=>date("Y-m-d"),'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],            
            ['id_absensi'=>"5",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."4",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"6",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."5",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"7",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."6",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"8",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."7",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"9",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."8",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"10",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."9",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"11",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."10",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"12",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."11",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"13",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."12",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"14",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."13",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"15",'id_karyawan'=>"1",'tgl'=>date("Y-m-")."14",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"16",'id_karyawan'=>"1",'tgl'=>"2017-01-04",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"17",'id_karyawan'=>"1",'tgl'=>"2017-01-05",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"18",'id_karyawan'=>"1",'tgl'=>"2017-01-06",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"19",'id_karyawan'=>"1",'tgl'=>"2017-01-07",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"20",'id_karyawan'=>"1",'tgl'=>"2017-01-08",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"21",'id_karyawan'=>"1",'tgl'=>"2017-01-09",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"22",'id_karyawan'=>"1",'tgl'=>"2017-01-10",'jam_masuk'=>"08:00:00",'jam_keluar'=>"20:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"23",'id_karyawan'=>"1",'tgl'=>"2017-01-11",'jam_masuk'=>"08:00:00",'jam_keluar'=>"20:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"24",'id_karyawan'=>"1",'tgl'=>"2017-01-12",'jam_masuk'=>"08:00:00",'jam_keluar'=>"20:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"25",'id_karyawan'=>"1",'tgl'=>"2017-01-13",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"],
            ['id_absensi'=>"26",'id_karyawan'=>"1",'tgl'=>"2017-01-14",'jam_masuk'=>"08:00:00",'jam_keluar'=>"18:00:00",'jam_istirahat1_keluar'=>"12:00:00",'jam_istirahat1_masuk'=>"12:00:00",'jam_istirahat2_keluar'=>"12:00:00",'jam_istirahat2_masuk'=>"12:00:00"]          
        ]);
        
        foreach ($dataabsensi as $data){
        	absensi::insert($data);
        }
    }
}

<?php

use Illuminate\Database\Seeder;
use App\User as user;

class userSeeder extends Seeder
{
    /**
    * Run the database seeds.
    *
    * @return void
    */
    public function run()
    {
        $datauser = array([
            ['id_biodata'=>1,'nama_lengkap'=>"A",'email'=>"tes1@gmail.com",'level'=>'master','password'=>bcrypt("tes12013")],
            ['id_biodata'=>2,'nama_lengkap'=>"B",'email'=>"tes2@gmail.com",'level'=>'admin','password'=>bcrypt("tes12014")],
            ['id_biodata'=>3,'nama_lengkap'=>"C",'email'=>"tes3@gmail.com",'level'=>'general manager','password'=>bcrypt("tes12015")],
            ['id_biodata'=>4,'nama_lengkap'=>"D",'email'=>"tes4@gmail.com",'level'=>'Karyawan','password'=>bcrypt("tes12016")]
        ]);
        foreach ($datauser as $data){
            user::insert($data);
        }
    }
}

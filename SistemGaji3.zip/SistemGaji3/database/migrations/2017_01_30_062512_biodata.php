<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Biodata extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('biodata', function (Blueprint $table) {
            $table->increments('id_biodata');
            $table->string('alamat',50)->nullable();
            $table->date('tanggal_lahir')->nullable();
            $table->enum('jenis_kelamin',["laki - laki","perempuan"]);
            $table->string('no_Hp',15)->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
     //@return 
     
    public function down()
    {
        Schema::drop('biodata');
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Peminjaman extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('peminjaman', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id_peminjaman');
            $table->integer('id_karyawan')->unsigned();
            $table->date('tgl_permohonan')->nullable();
            $table->date('tgl_ACC')->nullable();
            $table->enum('status',["Sedang Di Proses","Disetujui", "Tidak Disetujui"])->default("Sedang Di Proses");
            $table->date('tgl_pemberian')->nullable();
            $table->string('uraian',20)->nullable();
            $table->string('no_kwitansi',10)->nullable();
            $table->integer('jml_peminjaman')->nullable();
            $table->integer('cicilan')->nullable();
            $table->integer('masa_cicilan')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::table('peminjaman', function($table) {
            $table->foreign('id_karyawan')->references('id_karyawan')->on('karyawan');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
         Schema::drop('peminjaman');
    }
}

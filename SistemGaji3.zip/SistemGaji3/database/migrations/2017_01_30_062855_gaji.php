<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Gaji extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('gaji', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id_gaji'); 
            $table->integer('id_karyawan')->unsigned();
            $table->integer('honor_harian'); 
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::table('gaji', function($table) {
            $table->foreign('id_karyawan')->references('id_karyawan')->on('karyawan');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('gaji');
    }
}

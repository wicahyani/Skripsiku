<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Karyawan extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */    
    public function up()
    {
       Schema::create('karyawan', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id_karyawan');
            $table->integer('id')->unsigned();
            $table->date('tgl_masuk');
            $table->date('tgl_berhenti')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
       
        Schema::table('karyawan', function($table) {
            $table->foreign('id')->references('id')->on('users');
        });
    }

    public function down()
    {
      Schema::drop('karyawan');
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SlipGaji extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('slipGaji', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->integer('id_gaji')->unsigned();
            $table->integer('id_peminjaman')->unsigned();
            $table->integer('bonus');
            $table->integer('rembers');
            $table->date('tgl_terimagaji');
            $table->string('keterangan',20);
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::table('slipGaji', function($table) {
            $table->foreign('id_gaji')->references('id_gaji')->on('gaji');
            $table->foreign('id_peminjaman')->references('id_peminjaman')->on('peminjaman');
        }); 
    

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('slipGaji');
    }
}

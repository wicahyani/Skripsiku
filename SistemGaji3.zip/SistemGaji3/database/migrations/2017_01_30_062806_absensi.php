<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Absensi extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('absensi', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id_absensi');
            $table->integer('id_karyawan')->unsigned();
            $table->date('tgl');
            $table->time('jam_masuk')->nullable();
            $table->time('jam_keluar')->nullable();
            $table->time('jam_istirahat1_keluar')->nullable();
            $table->time('jam_istirahat1_masuk')->nullable();
            $table->time('jam_istirahat2_keluar')->nullable();
            $table->time('jam_istirahat2_masuk')->nullable();
            $table->string('keterangan')->default("Hadir");
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::table('absensi', function($table) {
            $table->foreign('id_karyawan')->references('id_karyawan')->on('karyawan');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('absensi');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class slipGajiModel extends Model
{
    protected $table = "slipGaji";
    protected $fillable = array("id_gaji","id_peminjaman","bonus","rembers","keterangan", "create_at", "update_at");
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class peminjamanModel extends Model
{
    protected $table = "peminjaman";
    protected $fillable = array("id_peminjaman","id_Karyawan","tgl_permohonan","tgl_acc","status","tgl_pemberian","uraian","no_kwitansi","jml_peminjaman","cicilan","masa_cicilan", "create_at", "update_at");
}

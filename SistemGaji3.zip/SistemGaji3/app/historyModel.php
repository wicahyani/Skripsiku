<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class historyModel extends Model
{
    protected $table = "history";
    protected $fillable = array("id_gaji","tgl_berlaku","tgl_berakhir","honor_harian", "create_at", "update_at");
}

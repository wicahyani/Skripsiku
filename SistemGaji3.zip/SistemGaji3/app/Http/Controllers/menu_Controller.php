<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\absensiModel as absensi;
use App\biodataModel as biodata;
use App\gajiModel as gaji;
use App\historyModel as history;
use App\lemburModel as lembur;
use App\KaryawanModel as Karyawan;
use App\peminjamanModel as peminjaman;
use App\slipGajiModel as slipGaji;
use App\User as users;

class menu_Controller extends Controller
{
    protected function index(){
        if (Auth::guest()) return redirect('/login');
        else return redirect('/Selamat Datang');
    }

    protected function select_all ($menu){
        $data['menu_aktif'] = $menu;
        $data['biodata_list']  = biodata::join('users','users.id_biodata', '=', 'biodata.id_biodata')->join('Karyawan','Karyawan.id', '=', 'users.id')->select('id_Karyawan','nama_lengkap','tgl_masuk','users.email','biodata.jenis_kelamin','users.id')->where('users.id', Auth::user()->id)->get();
        $list = null;
        switch ($menu) {
            case 'Data Karyawan':
                $dum = biodata::join('users','users.id_biodata', '=', 'biodata.id_biodata')->join('Karyawan','Karyawan.id', '=', 'users.id')->select('id_Karyawan','nama_lengkap','tgl_masuk','users.email','biodata.jenis_kelamin','users.id')->get();
                $i=0;
                foreach ($dum as $value) {
                    $list[$i][0] = $i;
                    $list[$i][1] = $value->nama_lengkap;
                    $list[$i][2] = $value->tgl_masuk;
                    $list[$i][3] = $value->id_Karyawan;
                    $list[$i][4] = $value->id;
                    $i++;
                }
                $data["list_user"]=users::all();
            break;
            case 'Data Pengguna':
                $dum= users::leftJoin('biodata','biodata.id_biodata', '=', 'users.id_biodata')->get();
                $i = 0;
                foreach ($dum as $value) {
                    $list[$i][0] = $i;
                    $list[$i][1] = $value->nama_lengkap;
                    $list[$i][2] = $value->email;
                    $list[$i][3] = $value->jenis_kelamin;
                    $list[$i][4] = $value->level;
                    $list[$i][5] = $value->id;
                    $list[$i][6] = $value->id_biodata;
                    $i++;
                }
            break;
            case 'Data Kasbon':
                $dum = peminjaman::join('Karyawan','Karyawan.id_Karyawan', '=', 'peminjaman.id_Karyawan')->join('users','users.id', '=', 'Karyawan.id')->select('Karyawan.id_Karyawan','id_peminjaman','nama_lengkap','tgl_permohonan','tgl_acc','peminjaman.status','tgl_pemberian','uraian','no_kwitansi','jml_peminjaman','cicilan','masa_cicilan')->get();
                $i=0;
                foreach ($dum as $value) {
                    $list[$i][0] = $i;
                    $list[$i][1] = $value->nama_lengkap;
                    $list[$i][2] = $value->tgl_permohonan;
                    $list[$i][3] = $value->tgl_acc;
                    $list[$i][4] = $value->status;
                    $list[$i][5] = $value->tgl_pemberian;
                    $list[$i][6] = $value->uraian;
                    $list[$i][7] = $value->no_kwitansi;
                    $list[$i][8] = $value->jml_peminjaman;
                    $list[$i][9] = $value->cicilan;
                    $list[$i][10] = $value->masa_cicilan;
                    $list[$i][11] = $value->id_peminjaman;
                    $list[$i][12] = $value->id_Karyawan;
                    $i++;
                }
            break;
            case 'Data Absen':
                $dum = Karyawan::join('users','users.id', '=', 'Karyawan.id')->join('absensi','absensi.id_Karyawan', '=', 'Karyawan.id_Karyawan')->where('users.id', Auth::user()->id)->get();
                $i=0;
                foreach ($dum as $value) {
                    $list[$i][0] = $i;
                    $list[$i][1] = $value->tgl;
                    $list[$i][2] = $value->nama_lengkap;
                    $list[$i][3] = $value->jam_masuk;
                    $list[$i][4] = $value->jam_keluar;
                    $list[$i][5] = $value->jam_istirahat1_keluar;
                    $list[$i][6] = $value->jam_istirahat1_masuk;
                    $list[$i][7] = $value->jam_istirahat2_keluar;
                    $list[$i][8] = $value->jam_istirahat2_masuk;
                    $list[$i][9] = $value->keterangan;
                    $list[$i][10] = $value->id_absensi;
                    $list[$i][11] = $value->id;
                    $i++;
                }
                $data["list_user"]=users::all();
            break;
            case 'Data Gaji':
                $dum = gaji::join('Karyawan','Karyawan.id_Karyawan', '=', 'gaji.id_Karyawan')->join('users','users.id', '=', 'Karyawan.id')->get();
                $i=0;
                foreach ($dum as $value) {
                    $list[$i][0] = $i;
                    $list[$i][1] = $value->nama_lengkap;
                    $list[$i][2] = $value->honor_harian;
                    $list[$i][3] = $value->id_gaji;
                    $list[$i][4] = $value->id;
                    $i++;
                }
                $data["list_user"]=users::all();
            break;
        }
        $data['raw_data'] = json_encode($list);
        return view('laman_muka',$data);
    }

    public function add(Request $request, $menu){
        $input = $request->all();
        switch ($menu) {
            case 'Data Karyawan':
                $result = array('id'=>$input['add_id'],'tgl_masuk' => $input['add_tgl_masuk']);
                $Karyawan = Karyawan::create($result); 
            break;
            case 'Data Pengguna':
                $result = array('jenis_kelamin' => $input['add_jenis_kelamin']);
                $biodata = biodata::create($result);
                $result = array('id_biodata'=>$biodata->id,'nama_lengkap' => $input['add_nama_lengkap'],'email' => $input['add_email'],'level'=>$input['add_level'],'password' =>md5($input['add_email']));
                users::create($result);             
            break;
            case 'Data Kasbon':
                $Karyawan = Karyawan::where('id', $input['add_id'])->get();
                $result = array('id_Karyawan'=> $Karyawan[0]->id_Karyawan,'tgl_permohonan' => $input['add_tgl_permohonan'],'uraian' => $input['add_uraian'], 'jml_peminjaman' => $input['add_jml_peminjaman'], 'cicilan' => $input['add_cicilan'], 'masa_cicilan' => $input['add_masa_cicilan']);
                peminjaman::create($result);
            break;
            case 'Data Absen Izin':
                $Karyawan = Karyawan::where('id', $input['add_id'])->get();
                $result = array('id_Karyawan'=> $Karyawan[0]->id_Karyawan,'tgl' => $input['add_tgl'],'keterangan' => $input['add_keterangan']);
                absensi::create($result);
                //var_dump($result);
                $menu = "Data Absen";
            break;
            case 'Data Gaji Karyawan':
                $Karyawan = Karyawan::where('id', $input['add_id'])->get();
                $result = array('id_Karyawan'=> $Karyawan[0]->id_Karyawan,'honor_harian' => $input['add_honor_harian']);
                gaji::create($result);
                $menu = "Data Gaji";
            break;            
        } 
        return redirect('/'.$menu);
    }   

    public function update(Request $request, $menu){
        $input = $request->all();
        switch ($menu) {
            case 'Data Pengguna':
                $result = array('nama_lengkap' => $input['edit_nama_lengkap'], 'email' => $input['edit_email'], 'level' => $input['edit_level']);
                users::where('id', $request -> input('edit_id'))->update($result);
                $result = array('jenis_kelamin' => $input['edit_jenis_kelamin']);
                biodata::where('id_biodata', $request -> input('edit_id_biodata'))->update($result);
            break;
            case 'Data Karyawan':
                $result = array('id' => $input['edit_id'], 'tgl_masuk' => $input['edit_tgl_masuk']);
                Karyawan::where('id_Karyawan', $request -> input('edit_id_Karyawan'))->update($result);
            break;
            case 'ACC Peminjaman':
                $result = array('tgl_acc' => $input['edit_tgl_acc'], 'status' => $input['edit_status'] );
                peminjaman::where('id_peminjaman', $request -> input('edit_id_peminjaman'))->update($result);
                $menu = "Data Kasbon";
            break;
            case 'Pemberian Kasbon':
                $result = array('tgl_pemberian' => $input['edit_tgl_pemberian'], 'no_kwitansi' => $input['edit_no_kwitansi'] );
                peminjaman::where('id_peminjaman', $request -> input('edit_id_peminjaman'))->update($result);
                $menu = "Data Kasbon";
            break;
            case 'Data Absen Izin':
                $Karyawan = Karyawan::where('id', $input['edit_id'])->get();
                $result = array('id_Karyawan'=> $Karyawan[0]->id_Karyawan,'tgl' => $input['edit_tgl'],'keterangan' => $input['edit_keterangan']);
                absensi::where('id_absensi', $request -> input('edit_id_absensi'))->update($result);
                $menu = "Data Absen";
            break;    
            case 'Data Gaji Karyawan':
                $Karyawan = Karyawan::where('id', $input['edit_id'])->get();
                $result = array('id_Karyawan'=> $Karyawan[0]->id_Karyawan,'honor_harian' => $input['edit_honor_harian']);
                gaji::where('id_gaji', $request -> input('edit_id_gaji'))->update($result);
                $menu = "Data Gaji";
            break;          
        }
        return redirect('/'.$menu);
    }

    public function delete($menu_aktif,$id){
        $dt = absensi::where('id_absensi', $id) -> delete();
        return redirect('/'. $menu_aktif);
    }

    public function delete_gaji($menu_aktif,$id){
        $dt = gaji::where('id_gaji', $id) -> delete();
        return redirect('/'. $menu_aktif);
    }

    public function delete_Karyawan($menu_aktif , $id_Karyawan){
        $dt = Karyawan::where('id_Karyawan', $id_Karyawan) -> delete();
        return redirect('/'. $menu_aktif);
    }
    
    public function delete_pengguna($menu_aktif , $id, $id_biodata){
        $dt = users::where('id', $id) -> delete();
        $dt = biodata::where('id_biodata', $id_biodata) -> delete();
        return redirect('/'. $menu_aktif);
    }


    public function login(Request $Request)
    {
        $input = $request->all();
        $db=users::where([['email', '=', $input['add_email']],['password', '=', $input['add_password']]])->get();
    }

    public function absen($menu_aktif,$absen,$id){
        $Karyawan = Karyawan::leftJoin('users','users.id', '=', 'Karyawan.id')->where('users.id',$id)->get();
        switch ($absen) {
            case 'absen_masuk':
                $result=array('id_Karyawan' => $Karyawan[0]->id_Karyawan,'tgl'=>date("Y-m-d"),'jam_masuk'=>date("H:i:s") );
                absensi::create($result);
            break;

            case 'absen_pulang':
                $result=array('jam_keluar'=>date("H:i:s"));
                absensi::where([['id_Karyawan', '=', $Karyawan[0]->id_Karyawan],['tgl', '=', date("Y-m-d")]])->update($result);
            break;

            case 'absen_istirahat1_keluar':
                $result=array('jam_istirahat1_keluar'=>date("H:i:s"));
                absensi::where([['id_Karyawan', '=', $Karyawan[0]->id_Karyawan],['tgl', '=', date("Y-m-d")]])->update($result);
            break;

            case 'absen_istirahat1_masuk':
                $result=array('jam_istirahat1_masuk'=>date("H:i:s"));
                absensi::where([['id_Karyawan', '=', $Karyawan[0]->id_Karyawan],['tgl', '=', date("Y-m-d")]])->update($result);
            break;
            case 'absen_istirahat2_keluar':
                $result=array('jam_istirahat2_keluar'=>date("H:i:s"));
                absensi::where([['id_Karyawan', '=', $Karyawan[0]->id_Karyawan],['tgl', '=', date("Y-m-d")]])->update($result);
            break;
            case 'absen_istirahat2_masuk':
                $result=array('jam_istirahat2_masuk'=>date("H:i:s"));
                absensi::where([['id_Karyawan', '=', $Karyawan[0]->id_Karyawan],['tgl', '=', date("Y-m-d")]])->update($result);
            break;
        }
        return redirect('/'. $menu_aktif);
    }
}

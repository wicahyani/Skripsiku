<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KaryawanModel extends Model
{
    protected $table = "Karyawan";
    protected $fillable = array("id_Karyawan","id_biodata","id","tgl_masuk","tgl_berhenti", "create_at", "update_at");
}
